import pandas as pd
import random
import copy
import matplotlib.pyplot as plt
import math
import sys, time

# show the process
def process_bar(num, total, t):
    rate = float(num)/total
    ratenum = int(100*rate)
    r = '\r[{}{}]{}%, {}mins'.format('*'*ratenum,' '*(100-ratenum), ratenum, t)
    sys.stdout.write(r)
    sys.stdout.flush()

# Initialize the conditions
# Input the distance matrix, need matrix, and the Maximum capacity of selecte vehicles
# Output the travel distance and numbers of vehicles for distributed mode and the initilized node list, the travel distance and working hours for transporting the waste unable to optimize for centralized mode.
def init_condition(Dist_M, Need_M, Vc_max, Speed, Dwt, ST):

    n = len(Need_M)
    org_needlist = {} # initilizing the needlist
    for i in range(n):

        org_needlist['S'+str(i)] = [Need_M[i] // Vc_max, Need_M[i] % Vc_max] # deviding waste volum in each node into the number of trips and residual amount
    # calculating the distance and numbers of vehicles for distributed mode
    dist_0, num_0 = 0, 0 # defining and initializing the distance and numbers of vehicles for ditributed mode
    for j in range(n):  

        dist_0 += Dist_M[j][0] * 2 * math.ceil(Need_M[j] / Vc_max) # calculating the travel distance of the distributed mode
        num_0 += math.ceil(1.2 *((2 * math.ceil(Need_M[j] / Vc_max) * (Dist_M[j][0] / Speed + ST)) / Dwt)) # calculating the numbers of vehicles of the distributed mode
    
    dist_1, w_time = 0, 0 # defining and initializing the travel distance and working hours for transporting the waste unable to optimize for centralized mode.
    needlist = {} # defining and initializing the node list
    for k in range(n):

        dist_1 += 2 * Dist_M[0][k] * (Need_M[k] // Vc_max) 
        w_time += (Dist_M[k][0] / Speed + ST) * 2 * (Need_M[k] // Vc_max)
        if org_needlist[list(org_needlist.keys())[k]][-1] != 0:

            needlist[list(org_needlist.keys())[k]] = org_needlist[list(org_needlist.keys())[k]][-1]

    needlist['S0'] = 0
    return dist_0, num_0, dist_1, w_time, needlist

# generating the an individual. The last 2 elements in the individual are the travel distance and numbers of vehicles.
# input the node list and the capacity of vehicle
def gen_individual(Nlist, Vc_max):
    
    candidate = copy.deepcopy(list(Nlist.keys()))
    candidate.remove('S0')
    random.shuffle(candidate)
    individual = ['S0']
    load = 0

    for s in candidate:

        if Nlist[s] <= Vc_max - load:
            
            individual.append(s)
            load += Nlist[s]

        else:

            individual.append('S0')
            individual.append(s)
            load = Nlist[s]
    individual.append('S0')       
    individual.append(0)
    return individual

# to check if an individual meets the capacity constraints
# input the individual, the node list, and the capacity of vehicle
def is_valid(individual, Nlist, Vc_max):

    result = True
    n = len(individual)
    load = 0

    for i in range(n-1):

        if individual[i] != 'S0':

            load += Nlist[individual[i]]

        else:

            if load > Vc_max:

                result = False
                break

            else:

                load = 0

    return result

# calculating the distance and number of vihicles of a solution
# input the individual, distance matrix, and the travel distance and working hours for transporting the waste unable to optimize for centralized mode.
def cal_fitness(individual, alpha, Dist_M, Dist_1, W_time, Speed, Dwt, ST):
    
    dist_1 =  Dist_1
    time = W_time
    # Dist_1 += Dist_M[0][int(individual[0][1:])]
    # time += Dist_M[0][int(individual[0][1:])]/Speed + ST

    for i in range(len(individual)-2):
        
        dist_1 += Dist_M[int(individual[i][1:])][int(individual[i+1][1:])]
        time += Dist_M[int(individual[i][1:])][int(individual[i+1][1:])]/Speed + ST

    Num_V = math.ceil(1.2 * time / Dwt)
    fitness = alpha * dist_1 + (1-alpha) * Num_V
    return fitness

# initializing the population
# input the node list, number of individuals in the population, distance matrix, distance and working time unable to optimize, travel speed, daily work hours, and stopping time for loading or unloading
def init_Pop(Nlist, alpha, Vc_max, NPop, Dist_M, Dist_1, W_time, Speed, Dwt, ST):

    population = []

    for i in range(NPop):

        individual = gen_individual(Nlist, Vc_max)
        individual[-1] = cal_fitness(individual, alpha, Dist_M, Dist_1, W_time, Speed, Dwt, ST)
        population.append(individual)

    return population

# Binary tournament selection
# input the population and return an individual
def sel_indiv(Population):

    n = len(Population)
    idx1, idx2 = random.randint(0,n-1), random.randint(0,n-1)
    if idx1 == idx2:

        idx2 = random.randint(0,n-1)
    
    if Population[idx1][-1] < Population[idx2][-1]:

            idx = idx1
    
    else:

            idx = idx2
   
    return Population[idx]

# Mutation
def mutate(individual1, Mu):

    individual = copy.deepcopy(individual1)

    if random.random() > Mu:
        
        n = len(individual)
        idx1, idx2 = random.randint(1,n-3), random.randint(1,n-3)
        
        if idx1 == idx2:

            idx2 = random.randint(1,n-3)

        individual[idx1], individual[idx2] = individual[idx2], individual[idx1]

    return individual
    
# generating children
def gen_children(population, alpha, Mu, nC, Nlist, Dist_M, Vc_max, Dist_1, W_time, Speed, Dwt, ST):

    children =[]

    for i in range(nC):

        child = mutate(sel_indiv(population), Mu)
        if is_valid(child, Nlist, Vc_max):

            child[-1] = cal_fitness(child, alpha, Dist_M, Dist_1, W_time, Speed, Dwt, ST)

        else:

            child[-1] = 200000
        
        children.append(child)    
    return children

# solving the VRP by evolution algorithm
def EAVRP(Dist_M, Need, Vc_max, alpha, NPop, Speed, Dwt, ST, Maxit, NMu, NC, figname):
    
    dist_0, num_0, dist_1, w_time, needlist = init_condition(Dist_M, Need, Vc_max, Speed, Dwt, ST)
    Parent1 = init_Pop(needlist, alpha[0], Vc_max, NPop, Dist_M, dist_1, w_time, Speed, Dwt, ST)
    Parent2 = init_Pop(needlist, alpha[1], Vc_max, NPop, Dist_M, dist_1, w_time, Speed, Dwt, ST)
    X, Y1, Y2 = [], [], []

    for i in range(Maxit):

        X.append(i)
        Children1 = gen_children(Parent1, alpha[0], NMu, NC, needlist, Dist_M, Vc_max, dist_1, w_time, Speed, Dwt, ST)
        Children2 = gen_children(Parent2, alpha[1], NMu, NC, needlist, Dist_M, Vc_max, dist_1, w_time, Speed, Dwt, ST)
        New_Pop1 = Parent1 + Children1
        New_Pop2 = Parent2 + Children2
        New_Pop1.sort(key = lambda x:x[-1])
        New_Pop2.sort(key = lambda x:x[-1])
        Parent1 = New_Pop1[0 : NPop]
        Parent2 = New_Pop2[0 : NPop]
        Y1.append(Parent1[0][-1])
        Y2.append(Parent2[0][-1])
    results = [dist_0, num_0, Parent1[0][-1], Parent2[0][-1]]

    fig, ax = plt.subplots(nrows = 1, ncols = 2, figsize = (15,7))
    plt.subplots_adjust(wspace = 0.18, hspace = 0.96, top = 0.95)

    ax[0].plot(X, Y1, alpha = 0.5, linewidth = 0.5)
    ax[1].plot(X, Y2, alpha = 0.5, linewidth = 0.5)

    ax[0].annotate(f'Δdist={round(100*(Y1[0]-Y1[-1])/Y1[0],2)}%', xy=(X[200], Y1[200]), xytext=(X[200]+20, Y1[200]+20))
    ax[1].annotate(f'Δnum_v={round(100*(Y2[0]-Y2[-1])/Y1[0],2)}%', xy=(X[200], Y2[200]), xytext=(X[200]+20, Y2[200]+0.05))

    ylabel = ['Distance/km','Number of vehicles/item']
    ax[0].set_xlabel('Iterations', fontsize = 14)
    ax[1].set_xlabel('Iterations', fontsize = 14)
    ax[0].set_ylabel(ylabel[0],  fontsize = 14)
    ax[1].set_ylabel(ylabel[1],  fontsize = 14)
    plt.suptitle(f"{figname}", fontsize = 16)
    plt.savefig("./converging_figures/%s.png"%(figname))
    plt.cla()

    return results

# defining the parameters
Vcap_max = [3.87, 4.91, 10.88, 13.61] # the capacity matrix of vehicles, t
Vehicle_size = ['M','M-E', 'L', 'XL'] # the labels of vehicles of different capacities
speed = 60 # the driving speed of the vehicles, km/h
dwt = 8 # the daily working hours,h
st = 0.25 # the stopping time for loading or unloading 
nPop = 100 # the size of the population
nC = 80 # the size of the child population
nMu = 0.5 # the mutate odds
MaxIt = 400 # the maximum iteration of EA
alpha = [1,0] # the value of alpha is either 1 or 0. If alpha = 1, the fitness is the distance, otherwise it's the number of vehicles.

if __name__ == "__main__":

    # importing the distance and need matrix
    for sn in range(2):

        data = pd.read_excel('data.xlsx', sheet_name=sn)
        dist = data[data.columns[0:-1]]
        need = pd.read_excel('need.xlsx', sheet_name=sn)
        results = {}
        results["Scenarios"] = ["dist_0", "num_0", "dist_1", "num_1"]
        start_time = time.time()
        for j in range(len(need.columns)):

            needi = list(need[need.columns[j]])

            for i in range(len(Vcap_max)):

                Fig_Name = 'county' + str(sn + 1) + need.columns[j] + ' + ' + Vehicle_size[i]
                results[Fig_Name] = EAVRP(dist, needi, Vcap_max[i], alpha, nPop, speed, dwt, st, MaxIt, nMu, nC, Fig_Name)
                now_time = time.time()
                process_bar(i + j* len(Vcap_max) + sn * len(need.columns) * len(Vcap_max), 
                            2 * len(need.columns) * len(Vcap_max), round((now_time-start_time)/60, 2))

        pd.DataFrame(results).to_excel("results_bigoal%d.xlsx"%(sn))

       