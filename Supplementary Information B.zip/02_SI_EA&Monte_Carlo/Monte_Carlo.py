import EAVRP
import pandas as pd
import random
import matplotlib.pyplot as plt
import sys, time

# show the process
def process_bar(num, total, t):
    rate = float(num)/total
    ratenum = int(100*rate)
    r = '\r[{}{}]{}%, {}mins'.format('*'*ratenum,' '*(100-ratenum), ratenum, t)
    sys.stdout.write(r)
    sys.stdout.flush()

# defining the parameters
Vcap_max = [3.87, 10.88, 13.61] # the capacity matrix of vehicles, t
Vehicle_size = ['M','L', 'EL' ]
Vcap_0 = [5, 10, 11.26] # curb weight matrix of vehicles, t
diesel = [0.38, 0.48, 0.53] # diesel consumption of the vehicles，L/km
fit_mode = ['DIST', 'NUMV'] # selection mode: optimize distance or number of vehicles
speed = 60 # the driving speed of the vehicles, km/h
dwt = 8 # the daily working hours,h
st = 0.25 # the stopping time for loading or unloading 
nPop = 100 # the size of the population
nC = 80 # the size of the child population
nMu = 0.5 # the mutate odds
EAIt = 400 # the maximum iteration of EA
MCIt = 1000 # the iteration of Monte-Carlo analysis

# Monte-Carlo analysis
start_time = time.time()
for sn in range(2):

    data = pd.read_excel("data.xlsx", sheet_name= sn)
    dist = data[data.columns[0:-1]]
    need = data[data.columns[-1]]
    results = {}
    results['Scenarios'] = ['Dist_0', 'Num_0', 'Dist_1','Num_1', 'Waste_volume']

    for vc in range(len(Vcap_max)):

        for i in range(MCIt):
        
            Need = []

            for j in range(len(need)):

                Need.append(random.gauss(need[j], 0.1*need[j]))

            results['iterations'+str(i)+'Vcap='+str(Vcap_max[vc])] = EAVRP.EAVRP(dist, Need, Vcap_max[vc], nPop, speed, dwt, st, EAIt, nMu, nC)
            # time.sleep(0.01)
            now_time = time.time()
            process_bar(3000 * sn + 1000 * vc + i, 6000, round((now_time - start_time) / 60, 2))


    pd.DataFrame(results).to_excel("1 Monte Carlo results of county %d.xlsx" % (sn))

