import random
import copy
import math
import sys, time
import pandas as pd

# show the process
def process_bar(num, total, t):
    rate = float(num)/total
    ratenum = int(100*rate)
    r = '\r[{}{}]{}%, {}mins'.format('*'*ratenum,' '*(100-ratenum), ratenum, t)
    sys.stdout.write(r)
    sys.stdout.flush()

# Initialize the conditions
# Input the distance matrix, need matrix, and the Maximum capacity of selecte vehicles
# Output the travel distance and numbers of vehicles for distributed mode and the initilized node list, the travel distance and working hours for transporting the waste unable to optimize for centralized mode.
def init_condition(Dist_M, Need_M, Vc_max, Speed, Dwt, ST):

    n = len(Need_M)
    org_needlist = {} # initilizing the needlist
    for i in range(n):

        org_needlist['S'+str(i)] = [Need_M[i] // Vc_max, Need_M[i] % Vc_max] # deviding waste volum in each node into the number of trips and residual amount
    # calculating the distance and numbers of vehicles for distributed mode
    dist_0, num_0 = 0, 0 # defining and initializing the distance and numbers of vehicles for ditributed mode
    for j in range(n):  

        dist_0 += Dist_M[j][0] * 2 * math.ceil(Need_M[j] / Vc_max) # calculating the travel distance of the distributed mode
        num_0 += math.ceil(1.2 *((2 * math.ceil(Need_M[j] / Vc_max) * (Dist_M[j][0] / Speed + ST)) / Dwt)) # calculating the numbers of vehicles of the distributed mode
    
    dist_1, w_time = 0, 0 # defining and initializing the travel distance and working hours for transporting the waste unable to optimize for centralized mode.
    needlist = {} # defining and initializing the node list
    for k in range(n):

        dist_1 += 2 * Dist_M[0][k] * (Need_M[k] // Vc_max) 
        w_time += (Dist_M[k][0] / Speed + ST) * 2 * (Need_M[k] // Vc_max)
        if org_needlist[list(org_needlist.keys())[k]][-1] != 0:

            needlist[list(org_needlist.keys())[k]] = org_needlist[list(org_needlist.keys())[k]][-1]

    needlist['S0'] = 0
    return dist_0, num_0, dist_1, w_time, needlist

# generating the an individual. The last 2 elements in the individual are the travel distance and numbers of vehicles.
# input the node list and the capacity of vehicle
def gen_individual(Nlist, Vc_max):
    
    candidate = copy.deepcopy(list(Nlist.keys()))
    candidate.remove('S0')
    random.shuffle(candidate)
    individual = ['S0']
    load = 0

    for s in candidate:

        if Nlist[s] <= Vc_max - load:
            
            individual.append(s)
            load += Nlist[s]

        else:

            individual.append('S0')
            individual.append(s)
            load = Nlist[s]
    individual.append('S0') 
    individual.append(0)      
    individual.append(0)
    return individual

# to check if an individual meets the capacity constraints
# input the individual, the node list, and the capacity of vehicle
def is_valid(individual, Nlist, Vc_max):

    result = True
    n = len(individual)
    load = 0

    for i in range(n-2):

        if individual[i] != 'S0':

            load += Nlist[individual[i]]

        else:

            if load > Vc_max:

                result = False
                break

            else:

                load = 0

    return result

# calculating the distance and number of vihicles of a solution
# input the individual, distance matrix, and the travel distance and working hours for transporting the waste unable to optimize for centralized mode.
def cal_fitness(individual, Dist_M, Dist_1, W_time, Speed, Dwt, ST):
    
    dist_1 =  Dist_1
    time = W_time
    # Dist_1 += Dist_M[0][int(individual[0][1:])]
    # time += Dist_M[0][int(individual[0][1:])]/Speed + ST

    for i in range(len(individual)-3):
        
        dist_1 += Dist_M[int(individual[i][1:])][int(individual[i+1][1:])]
        time += Dist_M[int(individual[i][1:])][int(individual[i+1][1:])]/Speed + ST

    Num_V = math.ceil(1.2 * time / Dwt)
    individual[-2] = Num_V
    individual[-1] = dist_1


# initializing the population
# input the node list, number of individuals in the population, distance matrix, distance and working time unable to optimize, travel speed, daily work hours, and stopping time for loading or unloading
def init_Pop(Nlist, Vc_max, NPop, Dist_M, Dist_1, W_time, Speed, Dwt, ST):

    population = []

    for i in range(NPop):

        individual = gen_individual(Nlist, Vc_max)
        cal_fitness(individual, Dist_M, Dist_1, W_time, Speed, Dwt, ST)
        population.append(individual)

    return population

# Binary tournament selection
# input the population and return an individual
def sel_indiv(Population):

    n = len(Population)
    idx1, idx2 = random.randint(0,n-1), random.randint(0,n-1)
    if idx1 == idx2:

        idx2 = random.randint(0,n-1)
    
    if Population[idx1][-1] < Population[idx2][-1]:

            idx = idx1
    
    else:

            idx = idx2
   
    return Population[idx]


# Mutation
def mutate(individual1, Mu):

    individual = copy.deepcopy(individual1)

    if random.random() > Mu:
        
        n = len(individual)
        idx1, idx2 = random.randint(1,n-4), random.randint(1,n-4)
        
        if idx1 == idx2:

            idx2 = random.randint(1,n-4)

        individual[idx1], individual[idx2] = individual[idx2], individual[idx1]

    return individual

def gen_children(population, Mu, nC, Nlist, Dist_M, Vc_max, Dist_1, W_time, Speed, Dwt, ST):

    children =[]

    for i in range(nC):

        child = mutate(sel_indiv(population), Mu)
        if is_valid(child, Nlist, Vc_max):

            cal_fitness(child, Dist_M, Dist_1, W_time, Speed, Dwt, ST)

        else:

            child[-1] = 200000
        
        children.append(child)

    return children        

# solving the VRP by evolution algorithm
def EAVRP(Dist_M, Need, Vc_max, NPop, Speed, Dwt, ST, Maxit, NMu, NC):
    
    dist_0, num_0, dist_1, w_time, needlist = init_condition(Dist_M, Need, Vc_max, Speed, Dwt, ST)
    Parent = init_Pop(needlist, Vc_max, NPop, Dist_M, dist_1, w_time, Speed, Dwt, ST)
    # X, Y = [], []

    for i in range(Maxit):

        # X.append(i)
        Children = gen_children(Parent, NMu, NC, needlist, Dist_M, Vc_max, dist_1, w_time, Speed, Dwt, ST)
        New_Pop = Parent + Children
        New_Pop.sort(key = lambda x:x[-1])
        Parent = New_Pop[0 : NPop]

    results = [dist_0, num_0, Parent[0][-1], Parent[0][-2], sum(Need)]

    return results

if __name__ == '__main__':

    # defining the parameters
    Vcap_max = [3.87, 10.88, 13.61] # the capacity matrix of vehicles, t
    Vehicle_size = ['M','L', 'EL' ]
    Vcap_0 = [5, 10, 11.26] # curb weight matrix of vehicles, t
    diesel = [0.38, 0.48, 0.53] # diesel consumption of the vehicles，L/km
    fit_mode = ['DIST', 'NUMV'] # selection mode: optimize distance or number of vehicles
    speed = 60 # the driving speed of the vehicles, km/h
    dwt = 8 # the daily working hours,h
    st = 0.25 # the stopping time for loading or unloading 
    nPop = 100 # the size of the population
    nC = 80 # the size of the child population
    nMu = 0.5 # the mutate odds
    MaxIt = 800 # the maximum iteration of EA
   

    results = {}
    results['Scenarios'] = ['Dist_0', 'Num_0', 'Dist_1','Num_1', 'waste_volume']
    county = ['Pei', 'Xiangshan']

    start_time = time.time()
    for sn in range(2):
        # importing the distance and need matrix
        data = pd.read_excel('data.xlsx', sheet_name = sn)
        dist = data[data.columns[0:-1]]
        need = pd.read_excel('need.xlsx', sheet_name = sn)

        for j in range(5):
    
            needi = need[need.columns[j]]

            for i in range(3):

                results[county[sn]+need.columns[j]+Vehicle_size[i]] = EAVRP(dist, needi, Vcap_max[i], nPop, speed, dwt, st, MaxIt, nMu, nC)
                now_time = time.time()
                process_bar(i+3*j+15*sn, 30, round((now_time-start_time)/60,2))

    pd.DataFrame(results).to_excel('results.xlsx')